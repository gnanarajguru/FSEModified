﻿using FullStackEngineer.Data.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace FullStackEngineer.Data
{
    public static class DataAccessResolver
    {
        /// <summary>
        /// Configure Data Services.
        /// </summary>
        /// <param name="services">services.</param>
        /// <param name="configuration">configuration.</param>
        public static void ConfigureDataServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.RegisterDataAccess();
        }

        /// <summary>
        /// Initialize Repository Layers.
        /// </summary>
        /// <param name="services">services.</param>
        public static void RegisterDataAccess(this IServiceCollection services)
        {
            services.AddScoped<IProjectManagementRepository, ProjectManagementRepository>();
        }
    }
}
