﻿USE [ProjectManagement]
GO

/****** Object:  Table [dbo].[TeamMemberDetail]    Script Date: 11-11-2022 08:45:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TeamMemberDetail](
	[MemberId] [int] IDENTITY(1,1) NOT NULL,
	[TeamMemberName] [varchar](50) NOT NULL,
	[YearsOfExperience] int NOT NULL,
	[NoofSkillset] int NOT NULL,
	[AdditionalDescription] [varchar](200) NOT NULL,
	[AllocationPercentage] [int] NOT NULL,
	[ProjectStartDate] [smalldatetime] NOT NULL,
	[ProjectEndDate] [smalldatetime] NOT NULL,
	[CreatedDate] [smalldatetime] NOT NULL,
	[ModifiedDate] [smalldatetime] NULL	
PRIMARY KEY CLUSTERED 
(
	[MemberId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO



CREATE TABLE [dbo].[TaskDetail](  
[Id] [int] PRIMARY KEY IDENTITY (1,1) NOT NULL
,[MemberName] [varchar](50) NOT NULL ,     
[MemberId] int foreign key references TeamMemberDetail(MemberId) NOT NULL,
[TaskName] [varchar](200) NOT NULL,   
[Deliverables] [varchar](100) NOT NULL ,     
[TaskStartDate] [smalldatetime] NOT NULL,
[TaskEndDate] [smalldatetime] NOT NULL,
[CreatedDate] [smalldatetime] NOT NULL,    
[ModifiedDate] [smalldatetime] NULL
)
Go

