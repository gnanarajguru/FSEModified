﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FullStackEngineer.API.Model
{
    public partial class TaskDetail
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [StringLength(50)]
        public string MemberName { get; set; }
        public int MemberId { get; set; }
        [Required]
        [StringLength(200)]
        public string TaskName { get; set; }
        [Required]
        [StringLength(100)]
        public string Deliverables { get; set; }
        [Column(TypeName = "smalldatetime")]
        public DateTime TaskStartDate { get; set; }
        [Column(TypeName = "smalldatetime")]
        public DateTime TaskEndDate { get; set; }
        [Column(TypeName = "smalldatetime")]
        public DateTime CreatedDate { get; set; }
        [Column(TypeName = "smalldatetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(MemberId))]
        [InverseProperty(nameof(TeamMemberDetail.TaskDetail))]
        public virtual TeamMemberDetail Member { get; set; }
    }
}
