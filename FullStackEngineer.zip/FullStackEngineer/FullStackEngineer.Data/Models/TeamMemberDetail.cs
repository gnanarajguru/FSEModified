﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FullStackEngineer.API.Model
{
    public partial class TeamMemberDetail
    {
        public TeamMemberDetail()
        {
            TaskDetail = new HashSet<TaskDetail>();
        }

        [Key]
        public int MemberId { get; set; }
        [Required]
        [StringLength(50)]
        public string TeamMemberName { get; set; }
        [Required]        
        public int YearsOfExperience { get; set; }

        [Required]
        public int NoofSkillset { get; set; }

        [Required]
        [StringLength(200)]
        public string AdditionalDescription { get; set; }
        [Column(TypeName = "smalldatetime")]
        public DateTime ProjectStartDate { get; set; }
        [Column(TypeName = "smalldatetime")]
        public DateTime ProjectEndDate { get; set; }
        [Column(TypeName = "smalldatetime")]
        public DateTime CreatedDate { get; set; }
        [Column(TypeName = "smalldatetime")]
        public DateTime? ModifiedDate { get; set; }
        public int AllocationPercentage { get; set; }

        [InverseProperty("Member")]
        public virtual ICollection<TaskDetail> TaskDetail { get; set; }
    }
}
