﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace FullStackEngineer.API.Model
{
    public partial class ProjectManagementContext : DbContext
    {
        public ProjectManagementContext()
        {
        }

        public ProjectManagementContext(DbContextOptions<ProjectManagementContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TaskDetail> TaskDetail { get; set; }
        public virtual DbSet<TeamMemberDetail> TeamMemberDetail { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=CTSDOTNET440;Database=ProjectManagement;user id = sa;password=pass@word1;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TaskDetail>(entity =>
            {
                entity.Property(e => e.Deliverables).IsUnicode(false);

                entity.Property(e => e.MemberName).IsUnicode(false);

                entity.Property(e => e.TaskName).IsUnicode(false);

                entity.HasOne(d => d.Member)
                    .WithMany(p => p.TaskDetail)
                    .HasForeignKey(d => d.MemberId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__TaskDetai__Membe__286302EC");
            });

            modelBuilder.Entity<TeamMemberDetail>(entity =>
            {
                entity.HasKey(e => e.MemberId)
                    .HasName("PK__TeamMemb__0CF04B18850DDD98");

                entity.Property(e => e.AdditionalDescription).IsUnicode(false);

                entity.Property(e => e.TeamMemberName).IsUnicode(false);

                entity.Property(e => e.YearsOfExperience).IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
