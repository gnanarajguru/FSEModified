﻿using FullStackEngineer.API.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FullStackEngineer.Data.Repositories
{
    public interface IProjectManagementRepository
    {
        public Task<int> AddTeamMember(TeamMemberDetail teamMemberDetail);

        public Task<List<TeamMemberDetail>> GetMemberDetail();

        public Task<int> AssignTask(TaskDetail taskDetail);

        public Task<TeamMemberDetail> ViewTask(int memberId);

        public Task<int> UpdateAllocation(TeamMemberDetail teamMemberDetail);
    }
}