﻿using FullStackEngineer.API.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FullStackEngineer.Data.Repositories
{
    public class ProjectManagementRepository : IProjectManagementRepository
    {
        private readonly ProjectManagementContext dbContext;

        public ProjectManagementRepository(ProjectManagementContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<int> AddTeamMember(TeamMemberDetail teamMemberDetail)
        {
            int result = 0;
            try
            {
                await this.dbContext.AddAsync(teamMemberDetail);
                await this.dbContext.SaveChangesAsync();

                result = teamMemberDetail.MemberId;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }

            return result;
        }

        public async Task<List<TeamMemberDetail>> GetMemberDetail()
        {
            return await this.dbContext.TeamMemberDetail.OrderByDescending(x => x.YearsOfExperience).ToListAsync();
        }

        public async Task<int> AssignTask(TaskDetail taskDetail)
        {
            int result = 0;
            try
            {
                await this.dbContext.AddAsync(taskDetail);
                await this.dbContext.SaveChangesAsync();

                result = taskDetail.Id;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }

            return result;
        }

        public async Task<TeamMemberDetail> ViewTask(int memberId)
        {
            return await this.dbContext.TeamMemberDetail.Include(x => x.TaskDetail).FirstOrDefaultAsync(w => w.MemberId == memberId);
        }

        public async Task<int> UpdateAllocation(TeamMemberDetail teamMemberDetail)
        {
            int result = 0;
            try
            {
                this.dbContext.Update(teamMemberDetail);
                result = await this.dbContext.SaveChangesAsync();
            }
            catch (System.Exception ex)
            {
                throw ex;
            }

            return result;
        }
    }
}
