﻿using FullStackEngineer.Data;
using FullStackEngineer.Service.Interface;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace FullStackEngineer.Service
{
    public static class ServiceResolver
    {
        /// <summary>
        /// Register Service Dependencies.
        /// </summary>
        /// <param name="services">service collection.</param>
        /// <param name="configuration">configurations.</param>
        public static void ConfigureServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.ConfigureDataServices(configuration);
            services.ConfigureFSEServices(configuration);
        }

        /// <summary>
        /// Register Service Dependencies.
        /// </summary>
        /// <param name="services">service collection.</param>
        /// <param name="configuration">configurations.</param>
        public static void ConfigureFSEServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IEngineerService, EngineerService>();
        }
    }
}
