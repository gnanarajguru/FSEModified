﻿using FullStackEngineer.API.Model;
using FullStackEngineer.Shared.Payloads.Requests;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FullStackEngineer.Service.Interface
{
    public interface IEngineerService
    {
        public Task<int> AddTeamMember(TeamMemberDetail teamMemberDetail);

        public Task<IEnumerable<TeamMemberDetail>> GetTeamMembers();

        public Task<int> AssignTask(TaskDetail taskDetail);

        public Task<TeamMemberDetail> GetTaskDetails(int memberId);

        public Task<bool> AllocationPercentage(TeamMemberDetail teamMemberDetail);

    }
}
