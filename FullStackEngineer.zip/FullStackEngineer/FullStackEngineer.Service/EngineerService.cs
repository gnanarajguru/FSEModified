﻿using FullStackEngineer.API.Model;
using FullStackEngineer.Data.Repositories;
using FullStackEngineer.Service.Interface;
using FullStackEngineer.Shared.Payloads.Requests;
using FullStackEngineer.Shared.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace FullStackEngineer.Service
{
    public class EngineerService : IEngineerService
    {
        private readonly IProjectManagementRepository projectManagementRepository;

        public EngineerService(IProjectManagementRepository projectManagementRepository)
        {
            this.projectManagementRepository = projectManagementRepository;
        }
        
        public async Task<int> AddTeamMember(TeamMemberDetail teamMemberDetail)
        {
            this.AddTeamMemberValidation(teamMemberDetail);            

            return await this.projectManagementRepository.AddTeamMember(teamMemberDetail);
        }

        
        public async Task<IEnumerable<TeamMemberDetail>> GetTeamMembers()
        {
            return await this.projectManagementRepository.GetMemberDetail();
        }

        public async Task<int> AssignTask(TaskDetail taskDetail)
        {
            this.AssignValidation(taskDetail);            

            return await this.projectManagementRepository.AssignTask(taskDetail);
        }

        public async Task<TeamMemberDetail> GetTaskDetails(int memberId)
        {
            return await this.projectManagementRepository.ViewTask(memberId);
        }
        
        public async Task<bool> AllocationPercentage(TeamMemberDetail teamMemberDetail)
        {
            int result = 0;
            if(teamMemberDetail.ProjectEndDate < DateTime.Now)
            {
                teamMemberDetail.MemberId = teamMemberDetail.MemberId;
                teamMemberDetail.AllocationPercentage = 0;
            }
            else
            {
                teamMemberDetail.MemberId = teamMemberDetail.MemberId;
                teamMemberDetail.AllocationPercentage = 100;
            }
            result = await this.projectManagementRepository.UpdateAllocation(teamMemberDetail);
            
            return result > 0;
            
        }

        private bool AddTeamMemberValidation(TeamMemberDetail teamMemberDetail)
        {
            bool validation = false;
            if (teamMemberDetail.YearsOfExperience > 4 && teamMemberDetail.NoofSkillset >=3 )
            {
                validation = true;
            }
            else
            {
                throw new CustomException("Years of Experience is less than 4 Years (or) No of skillset is less than 3");
            }           
            
            return validation;
        }

        private bool AssignValidation(TaskDetail taskDetail)
        {
            bool validation = false;
            if (taskDetail.TaskEndDate > taskDetail.TaskStartDate)
            {
                validation = true;
            }
            else
            {
                throw new CustomException("Task End date should be greter than task start date");
            }

            return validation;
        }
       
    }
}
