﻿using System;

namespace FullStackEngineer.Shared.Utility
{
    [Serializable]
    public class CustomException : Exception
    {
        public bool IsRequestValidateion { get; }
        public CustomException()
        {
        }

        public CustomException(string message) : base(message)
        {

        }

        public CustomException(string message, bool isRequestValidateion) : base(message)
        {
            this.IsRequestValidateion = IsRequestValidateion;
        }
    }
}
