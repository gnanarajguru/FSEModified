﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace FullStackEngineer.Shared.Payloads.Requests.Validators
{
    public class ProfileRequestValidator : AbstractValidator<ProfileRequest>
    {
        public ProfileRequestValidator()
        {
            this.RuleFor(x => x.Name)
                .Cascade(CascadeMode.StopOnFirstFailure)
                .NotEmpty().WithMessage("Name mandatory field")
                .NotNull().WithMessage("Name not null")
                .MinimumLength(5).WithMessage("Name minimum length should be 5 or more")
                .MaximumLength(30).WithMessage("Name maximum length should not be greater than 30");

            this.RuleFor(x => x.AssociateId)
                .Cascade(CascadeMode.StopOnFirstFailure)
                .NotEmpty().WithMessage("AssociateId mandatory field")
                .NotNull().WithMessage("AssociateId not null")
                .MinimumLength(5).WithMessage("AssociateId minimum length should be 5 or more")
                .MaximumLength(30).WithMessage("AssociateId maximum length should not be greater than 30")
                .Must(str => str.StartsWith("CTS")).WithMessage("AssociateId should start with CTS");

            this.RuleFor(x => x.Email)
                .Cascade(CascadeMode.StopOnFirstFailure)
                .NotEmpty().WithMessage("Email mandatory field")
                .NotNull().WithMessage("Email not null")
                .MaximumLength(200).WithMessage("Email maximum length should not be greater than 30")
                .EmailAddress().WithMessage("Invalid email Id")
                .Must(str => str.Contains("@")).WithMessage("Email must contains with @");

            this.RuleFor(x => x.Mobile)
                .Cascade(CascadeMode.StopOnFirstFailure)
                .NotEmpty().WithMessage("Mobile mandatory field")
                .NotNull().WithMessage("Mobile not null")
                .MinimumLength(10).WithMessage("Mobile number minimum length should be 10")
                .MaximumLength(10).WithMessage("Mobile number maximum length should not be greater than 10")
                .Matches(new Regex(@"^[0-9]+$")).WithMessage("Mobile number should be integer value");

            this.RuleFor(x => x.ProfileSkills)
                .Cascade(CascadeMode.StopOnFirstFailure)
                .NotNull().WithMessage("expertise level should not be null")
                .NotEmpty().WithMessage("expertise level should not be empty")
                .Must(s => s.Count > 0).WithMessage("expertise levels count should be greater than 0")
                .Must(s => s.Count <= 20).WithMessage("expertise levels count should not be greater than 20");
        }
    }
}
