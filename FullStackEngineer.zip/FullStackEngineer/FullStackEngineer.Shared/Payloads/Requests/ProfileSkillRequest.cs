﻿namespace FullStackEngineer.Shared.Payloads.Requests
{
    public class ProfileSkillRequest
    {
        public string SkillName { get; set; }
        public string ExpertiseLevel { get; set; }
        public bool IsTechnicalSkill { get; set; }
    }
}
