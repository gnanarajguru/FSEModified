﻿using System.Collections.Generic;

namespace FullStackEngineer.Shared.Payloads.Requests
{
    public class ProfileRequest
    {
        public string Name { get; set; }
        public string AssociateId { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }

        public IList<ProfileSkillRequest> ProfileSkills { get; set; }
    }
}
