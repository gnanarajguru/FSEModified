﻿using FullStackEngineer.API.Constants;
using FullStackEngineer.API.Model;
using FullStackEngineer.Service.Interface;
using FullStackEngineer.Shared.Payloads.Requests;
using FullStackEngineer.Shared.Utility;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FullStackEngineer.API.Controllers
{
    [Route(RoutingConstants.ApiEngineerControllerRoutePrefix)]
    [ControllerName(RoutingConstants.ApiEngineerControllerName)]
    public class EngineerController : Controller
    {
        private readonly IEngineerService engineerService;

        public EngineerController(IEngineerService engineerService)
        {
            this.engineerService = engineerService;
        }

        [HttpPost(RoutingConstants.AddMember)]
        public async Task<IActionResult> AddMember(            
            [FromBody] TeamMemberDetail teamMemberDetail)
        {
            try
            {
                var result = await this.engineerService.AddTeamMember(teamMemberDetail);
                return Ok(result);
            }
            catch (CustomException ex)
            {
                return new BadRequestObjectResult(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        
        /// <summary>
        /// Get engineer list.
        /// </summary>
        /// <returns></returns>
        [HttpGet(RoutingConstants.GetMemberDetails)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<TeamMemberDetail>))]
        public async Task<IActionResult> GetTeamMembers()
        {
            var result = await this.engineerService.GetTeamMembers();
            return Ok(result);
            
        }

        
       
        [HttpPost(RoutingConstants.AssignTask)]
        public async Task<IActionResult> AssignTask(
            
            [FromBody] TaskDetail taskDetail)
        {
            try
            {
                var result = await this.engineerService.AssignTask(taskDetail);
                return Ok(result);
            }
            catch (CustomException ex)
            {

                return new BadRequestObjectResult(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }


        
        /// <summary>
        /// Get engineer list.
        /// </summary>
        /// <returns></returns>
        [HttpGet(RoutingConstants.ViewAssignedTask)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<TeamMemberDetail>))]
        public async Task<IActionResult> GetTaskDetails(int memberId)
        {
            var result = await this.engineerService.GetTaskDetails(memberId);
            return Ok(result);

        }

        
        [HttpPut(RoutingConstants.UpdatePercentage)]
        public async Task<IActionResult> AllocationPercentage(            
            [FromBody] TeamMemberDetail teamMemberDetail)
        {
            try
            {
                var result = await this.engineerService.AllocationPercentage(teamMemberDetail);
                return Ok(result);
            }
            catch (CustomException ex)
            {
                return new BadRequestObjectResult(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        
    }
}
