using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using FullStackEngineer.API.Constants;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerUI;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;
using FullStackEngineer.Service;
using FluentValidation.AspNetCore;
using FullStackEngineer.API.Model;

namespace FullStackEngineer.API
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers()
                .AddFluentValidation(s =>
                {
                    s.RegisterValidatorsFromAssemblyContaining<Startup>();
                    s.RunDefaultMvcValidationAfterFluentValidationExecutes = false;
                });

            services.AddControllers().AddNewtonsoftJson(options => options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore);
            
            services.AddApiVersioning(o =>
            {
                o.AssumeDefaultVersionWhenUnspecified = true;
                o.DefaultApiVersion = ApiVersion.Default;
                o.ReportApiVersions = true;

                o.ApiVersionReader = ApiVersionReader.Combine(
                    new QueryStringApiVersionReader("api-version"),
                    new HeaderApiVersionReader("api-version"));
            });

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc(APIConstants.SwaggerUI_V1_Name, new OpenApiInfo { Version = APIConstants.SwaggerUI_V1_Version, Title = APIConstants.SwaggerUI_V1_Title, Description = "Skill-Tracker Engineer" });
            });

            var ConnectionString = Configuration.GetConnectionString("SkillTrackerEngineerDbConstr");

            services.AddDbContext<ProjectManagementContext>(options => options.UseSqlServer(ConnectionString));

            services.ConfigureServices(this.Configuration);
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment()) app.UseDeveloperExceptionPage();
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseAuthorization();
            app.UseEndpoints(endpoints => { endpoints.MapControllers(); });
            app.UseSwagger();
            app.UseSwaggerUI(option =>
            {

                option.DefaultModelRendering(ModelRendering.Example);
                option.DefaultModelsExpandDepth(-1);
                option.DisplayRequestDuration();
                option.DocExpansion(DocExpansion.None);
                option.SwaggerEndpoint(APIConstants.SwaggerUI_V1_Specification_UrlPath, APIConstants.SwaggerUI_V1_Name);
                option.DocumentTitle = APIConstants.SwaggerUI_V1_Title;
            });
        }
    }
}
