﻿namespace FullStackEngineer.API.Constants
{
    internal class APIConstants
    {
        /// <summary>
        /// Swagger UI Name
        /// </summary>
        internal const string SwaggerUI_V1_Name = "v1";

        /// <summary>
        /// Swagger UI V1 Title
        /// </summary>
        internal const string SwaggerUI_V1_Title = "Skill-Tracker Engineer";

        /// <summary>
        /// Swagger UI V1 Version
        /// </summary>
        internal const string SwaggerUI_V1_Version = "v1";

        /// <summary>
        /// File Extenstion XML
        /// </summary>
        internal const string File_Extenstion_XML = "xml";

        /// <summary>
        /// Swagger Keyword v
        /// </summary>
        internal const string Swagger_Keyword_v = "v";

        /// <summary>
        /// Swagger UI V1 Specification Url Path
        /// </summary>
        internal const string SwaggerUI_V1_Specification_UrlPath = "/swagger/v1/swagger.json";
        
    }
}
