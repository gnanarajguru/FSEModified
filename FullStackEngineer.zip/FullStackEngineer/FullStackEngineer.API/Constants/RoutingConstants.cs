﻿namespace FullStackEngineer.API.Constants
{
    internal class RoutingConstants
    {
        /// <summary>
        /// Api Version V1
        /// </summary>
        internal const string ApiVersionV1= "v1";

        /// <summary>
        /// Controller route - Engineer.
        /// </summary>
        internal const string ApiEngineerControllerRoutePrefix = "api/v1/manager";

        /// <summary>
        /// Api Controller Name
        /// </summary>
        internal const string ApiEngineerControllerName = "manager";

        /// <summary>
        /// Engineer Add Member
        /// </summary>
        internal const string AddMember = "add-member";

        /// <summary>
        /// Get Member Details
        /// </summary>
        internal const string GetMemberDetails = "list/{memberDetails}";

        /// <summary>
        /// Engineer Assigned Task
        /// </summary>
        internal const string AssignTask = "assign-task";

        /// <summary>
        /// Engineer task details
        /// </summary>
        internal const string ViewAssignedTask = "list/{memberId}/{taskDetails}";

        /// <summary>
        /// Engineer update allocation percentage
        /// </summary>
        internal const string UpdatePercentage = "update/{allocationPercentage}";
    }
}
